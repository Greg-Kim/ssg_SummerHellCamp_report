<?php

function get_mem()
{
    return ['greg', 'minjoon', 'kim'];
}
 
$members = get_mem();
 
for($i = 0; $i < count($members); $i++)
{
    echo ucfirst($members[$i]).'<br />';
}
 
?>
