<?php

$arr = ['a', 'b', 'c'];

for($i=0; $i < count($arr); $i++)
{
	echo ' '.$arr[$i];
}
echo '<br />';


#push
array_push($arr, 'd');

for($i=0; $i < count($arr); $i++)
{
	echo ' '.$arr[$i];
}
echo '<br />';


#pop
array_pop($arr);

for($i=0; $i < count($arr); $i++)
{
	echo ' '.$arr[$i];
}
echo '<br />';


#unshift
array_unshift($arr, 'z');

for($i=0; $i < count($arr); $i++)
{
	echo ' '.$arr[$i];
}
echo '<br />';


#shift
array_shift($arr);

for($i=0; $i < count($arr); $i++)
{
	echo ' '.$arr[$i];
}
echo '<br />';


#splice
array_splice($arr, 1, 0, 'z');

for($i=0; $i < count($arr); $i++)
{
	echo ' '.$arr[$i];
}
echo '<br />';


#merge
$arr = array_merge($arr, ['x', 'y']);

for($i=0; $i < count($arr); $i++)
{
	echo ' '.$arr[$i];
}
echo '<br />';


#sort
sort($arr);

for($i=0; $i < count($arr); $i++)
{
	echo ' '.$arr[$i];
}
echo '<br />';

#rsort
rsort($arr);

for($i=0; $i < count($arr); $i++)
{
	echo ' '.$arr[$i];
}
echo '<br />';


#dict
$dict = ['key'=>'value', 'greg'=>'GREG', 'kim'=>'KIM'];

echo $dict['key'].'<br />';

foreach($dict as $key => $value)
{
	echo 'key: '.$key.' value: '.$value.'<br />';
}


?>
