<?php

$dir = getcwd();
echo $dir.'<br />';

$file = scandir($dir);
print_r($file);

if(!mkdir($dir."/new", 7777, true))
{
	echo "fail";
}

?>
