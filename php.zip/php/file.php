<?php

$file = 'file.txt';

if(file_exists($file))
{
	if(is_readable($file))
	{
		echo 'file is readable<br />';
	}

	if(is_writable($file))
	{
		echo 'file is writable<br />';
	}

	file_put_contents($file, 'greg kim');
	echo file_get_contents($file);
}
else
{
	echo 'Error! no file<br />';
}

?>
