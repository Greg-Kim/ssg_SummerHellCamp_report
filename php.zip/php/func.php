<?php

namespace en;

function hi()
{
	return 'Hello<br />';
}

?>
