<?php

namespace fr;

function hi()
{
	return 'Bonjour<br />';
}

?>
