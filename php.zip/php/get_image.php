<!DOCTYPE html>

<?php

$dir = getcwd();
$path = $dir.'/file/'.basename($_FILES['target']['name']);

echo 'upload path : '.$path.'<br />';

if (move_uploaded_file($_FILES['target']['tmp_name'], $path))
{
    echo "success\n";
}
else
{
    print "fail\n";
}

?>

<img src="file/<?=$_FILES['target']['name']?>"/>

