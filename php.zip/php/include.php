<?php

include 'func.php';
include 'func2.php';

echo en\hi();
echo fr\hi();

?>
