<meta charset="utf-8"/>

<?php

session_start();

$connect = mysqli_connect("localhost", "root", "ssg!", "user");

if(!$connect)
{
	echo "Error connect<br />";
}

$id = $_POST['id'];
$pw = $_POST['pw'];

if($id==NULL || $pw==NULL)
{
	echo "plz fill all the blank<br />";
}

$q = "SELECT * FROM member WHERE id='".$id."'";
$result = mysqli_query($connect, $q);
$member = mysqli_fetch_assoc($result);
$hash_pw = $member['pw'];

if(password_verify($pw, $hash_pw))
{
	$_SESSION['id'] = $member['id'];
	echo "Login Success<br />";
	echo "<a href=main.php>go to profile</a>";
}
else
{
	echo "Login Fail<br />";
}
?>
