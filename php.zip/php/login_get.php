<html>

<body>
	<form method="get" action="welcome_get.php">
		id : <input type="text" name="id"/> <br />
		pw : <input type="text" name="pw"/> <br />
		<input type="submit"/>
	</form>
</body>

</html>
