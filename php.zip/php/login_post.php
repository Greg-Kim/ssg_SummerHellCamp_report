<html>

<body>
	<form method="POST" action="welcome_post.php">
		id : <input type="text" name="id"/> <br />
		pw : <input type="text" name="pw"/> <br />
		<input type="submit"/>
	</form>
</body>

</html>
