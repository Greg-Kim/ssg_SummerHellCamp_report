<meta charset="utf-8">

<?php

session_start();
session_destroy();

?>

<script>alert("logout success"); location.href="main.php";</script>
