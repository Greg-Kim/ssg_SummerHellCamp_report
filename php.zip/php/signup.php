<meta charset="utf-8"/>

<?php

$connect = mysqli_connect("localhost", "root", "ssg!", "user");

if(!$connect)
{
	echo "Error connect<br />";
}

$id = $_POST['id'];
$pw = password_hash($_POST['pw'], PASSWORD_DEFAULT);
$nm = $_POST['nm'];
$bd = $_POST['bd'];

if($id==NULL || $pw==NULL || $nm==NULL || $bd==NULL)
{
	echo "plz fill all the blank<br />";
}

$q = "INSERT INTO member (id, pw, nm, bd) VALUES('".$id."', '".$pw."', '".$nm."', '".$bd."')";
$result = mysqli_query($connect, $q);

if($result)
{
	echo "Success!!<br />";
	echo "<a href=login.html>go to login</a>";
}


?>
