<html>

<?php
echo "id : ".$_GET['id'].'<br />';
echo "pw : ".$_GET['pw'];
?>

</html>
