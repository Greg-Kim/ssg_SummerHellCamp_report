<html>

<?php
echo "id : ".$_POST['id'].'<br />';
echo "pw : ".$_POST['pw'];
?>

</html>
